<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iphone 15 Pro Max</title>
</head>
<body>
    <div class="d1">
        <div class="d2">
            
        </div>
    </div>
</body>
</html>