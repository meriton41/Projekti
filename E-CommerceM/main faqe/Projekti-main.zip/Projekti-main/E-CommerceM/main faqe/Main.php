<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title id="title">Thalia Online Shop | buy Books, eBooks, Toys etc. | Thalia </title> 

    <script src="config_page1.json" type="application/json" id="config"></script>

    <link rel="stylesheet" href="First.css">
    <link rel="website icon" type="png" href="C:\Users\online\OneDrive\Desktop\Projekti Web\Projekti\E-CommerceM\main faqe\Fotot\Untitled.png">

    <nav>
        <a href="Main.html"> 
            <img class="thaliaLogo" src="Screenshot 2023-11-16 221803 1.png" alt="Thalia" height="10%" width="15%">
        </a>

        <div class="search-container">
            <input type="text" class="search-input" placeholder="Title, author, keyword, ISBN">

            <button class="search-button" type="submit" onclick="funksioniSearch()" >
            </button>
        </div>

        <ul class="Items">
            <li><a href="" class="active">My Account</a></li>
            <li><a href="#">Wish List</a></li>
            <li><a href="#">Shopping cart</a></li>
        </ul>

        <ul class="Librat">
            <a href="e-comerce.html" >Phones,Tablets</a>
            <a href="Computers.html">Computers&Servers</a>
            <a href="#">TV,Audio,Foto</a>
            <a href="#">Gaming</a>
            <a href="#">Accessory</a>
            <a href="us.html">About Us</a>
            <a href="#">Contact Us</a>
        </ul>


    </nav>

    <style>

        .login-container {
            display: none;
            position: absolute;
            top: 70px; 
            right: 160px; 
            background-color: white;
            z-index: 1000;
            padding: 10px; 
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2); 
            border-radius: 5px; 
            max-width: 200px; 
            text-align: center; 
        }

        .login-form {
            margin: 0;
            color: #292929;
            font-family: Circular,Segoe UI,Candara,Bitstream Vera Sans,DejaVu Sans,Trebuchet MS,Verdana,Verdana Ref,"sans-serif";
            font-size: 15px;
            font-weight: 700;
            line-height: 22px;
            text-decoration: none;

        }

        .login-form input {
            width: 100%;
            box-sizing: border-box;
            margin-bottom: 10px;
            padding: 5px;
            
        }

        .login-form button {
            width: 69%;
            padding: 8px;
            color: white;
            background-color: #1a1aaa;
            border: 0;
            border-radius: 23px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            color: #fff;
            cursor: pointer;
            display: inline-block;
            font-family: Circular,Segoe UI,Candara,Bitstream Vera Sans,DejaVu Sans,Trebuchet MS,Verdana,Verdana Ref,"sans-serif";
            font-size: 17px;
            font-weight: 700;
            line-height: 30px;
            outline: none;
            padding: 8px 30px;
            position: relative;
            text-align: center;
            text-decoration: none;

        }

    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const loginContainer = document.querySelector('.login-container');
            const myAccountLink = document.querySelector('.Items .active');
            const loginForm = document.querySelector('.login-form');

            myAccountLink.addEventListener('click', function (event) {
                event.preventDefault();

                loginContainer.style.display = (loginContainer.style.display === 'flex') ? 'none' : 'flex';
            });


            document.addEventListener('click', function (event) {
                if (!loginContainer.contains(event.target) && event.target !== myAccountLink) {
                    loginContainer.style.display = 'none';
                }
            });
        });
    </script>

</head>


<body>

    <div class="slideshow-container">
   
    <div class="mySlides fade">
      <a href="Computers.html" target="_blank"> <img src="https://assets.brack.ch/images2/6/2/4/311943426/311943426_xxl3.jpg" style="width:100%"></a>
    </div>
    <div class="mySlides fade">
        <a href="Computers.html" target="_blank"><img src="https://assets.brack.ch/images2/1/9/3/287091391/287091391_xxl3.jpg" style="width:100%"></a>
    </div>
    
    <div class="mySlides fade">
       <a href="e-comerce.html" target="_blank"> <img src="https://assets.brack.ch/images2/5/5/3/287091355/287091355_xxl3.jpg" style="width:100%"></a>
    </div>

    <div class="mySlides fade">
        <a href="e-comerce.html" target="_blank"> <img src="https://assets.brack.ch/images2/9/7/2/268281279/268281279_xxl3.jpg" style="width:100%"></a>
    </div>

    <div class="mySlides fade">
       <a href="e-comerce.html" target="_blank"> <img src="https://assets.brack.ch/images2/2/8/2/268281282/268281282_xxl3.jpg" style="width: 100%;"></a>
    </div>

    <div class="mySlides fade">
        <a href="Computers.html" target="_blank"> <img src="https://assets.brack.ch/images2/3/2/4/287091423/287091423_xxl3.jpg" style="width: 100%;"></a>
    </div>

    <div class="mySlides fade">
        <a href="Computers.html" target="_blank"> <img src="https://assets.brack.ch/images2/0/6/4/287091460/287091460_xxl3.jpg" style="width: 100%;"></a>
    </div>

    <div class="mySlides fade">
        <a href="Computers.html" target="_blank"> <img src="https://assets.brack.ch/images2/6/4/6/221362646/221362646_xxl3.jpg" style="width: 100%;"></a>
    </div>
    
    </div>


    <div style="text-align:center">
        <span class="dot"></span> 
        <span class="dot"></span> 
        <span class="dot"></span> 
        <span class="dot"></span> 
        <span class="dot"></span> 
        <span class="dot"></span> 
        <span class="dot"></span> 
        <span class="dot"></span> 
    </div>
      
      <script>
      let slideIndex = 0;
      showSlides();
      
      function showSlides() {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("dot");
        for (i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";  
        }
        slideIndex++;
        if (slideIndex > slides.length) {slideIndex = 1}    
        for (i = 0; i < dots.length; i++) {
          dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex-1].style.display = "block";  
        dots[slideIndex-1].className += " active";
        setTimeout(showSlides, 3000); 
      }
      </script>
    <br><br><br><br>

    <div class="row"> 
        <div class="column">
          <img src="https://assets.brack.ch/images2/1/3/3/287091331/287091331_xxl3.jpg" >
          <img src="https://assets.brack.ch/images2/9/8/3/181734389/181734389_xxl3.jpg">
          <img src="https://assets.brack.ch/images2/4/4/6/302833644/302833644_xxl3.jpg">
          <img src="https://iqq6kf0xmf.gjirafa.net/images/4d1a5a7d-6c24-4208-9eb7-cbf616d5683c/4d1a5a7d-6c24-4208-9eb7-cbf616d5683c.webp?w=400" >
          <img src="https://assets.brack.ch/images2/7/1/4/311943417/311943417_xxl3.jpg">
          <img src="https://assets.brack.ch/images2/0/1/4/311943410/311943410_xxl3.jpg">
          <img src="https://iqq6kf0xmf.gjirafa.net/images/dc404db5-7e13-4201-adc9-2a183092c1f8/dc404db5-7e13-4201-adc9-2a183092c1f8.webp?w=400">
          <img src="https://iqq6kf0xmf.gjirafa.net/images/97753ece-3951-4d9b-b245-f0b140b634dc/97753ece-3951-4d9b-b245-f0b140b634dc.jpeg">
          <img src="https://iqq6kf0xmf.gjirafa.net/images/2a5187ce-d161-4f2a-834e-6defbb2e4013/2a5187ce-d161-4f2a-834e-6defbb2e4013.jpeg">
          <img src="https://iqq6kf0xmf.gjirafa.net/images/64bcae26-97c7-4d68-8c49-f4a140da57a0/64bcae26-97c7-4d68-8c49-f4a140da57a0.webp?w=400">
          <img src="https://iqq6kf0xmf.gjirafa.net/images/42a6331d-0297-488b-81c7-f1161c658dbc/42a6331d-0297-488b-81c7-f1161c658dbc.webp?w=400">
          <img src="https://assets.brack.ch/images2/5/2/7/235129725/235129725_xxl.jpg">
          <img src="https://iqq6kf0xmf.gjirafa.net/images/d75db5ca-c1b6-4ed2-895c-dd67a66b113f/d75db5ca-c1b6-4ed2-895c-dd67a66b113f.webp?w=400">
          <img src="https://iqq6kf0xmf.gjirafa.net/images/669a16b9-7451-4a33-9c90-b266759d00ae/669a16b9-7451-4a33-9c90-b266759d00ae.webp?w=400">
          <img src="https://assets.brack.ch/images2/2/7/6/235128672/235128672_xxl3.jpg">
        
        </div>
      </div>

      <br><br><br>
      <button class="button button1">Show more</button>

      <div class="login-container">
        <form class="login-form" onsubmit=" return validimi()">
            <h2 style="font-family:  Circular,Segoe UI,Candara,Bitstream Vera Sans,DejaVu Sans,Trebuchet MS,Verdana,Verdana Ref,"sans-serif";;">I already have an account</h2>
            <label for="email">E-Mail:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br><br>

            <button type="submit" onclick="validimi()">Login</button><br><br>
            <a href="LoginForm.html" style="text-decoration: none; color:black">Create an account</a>
       </form>
    </div>
    

   <br><br>
    <img src="C:\Users\online\OneDrive\Desktop\Projekti Web\Projekti\E-CommerceM\main faqe\Fotot\Partners.png">

    <footer><br>


        <div class="footer_elements">
        
        <div class="AboutUs"> 
            <p style="font-weight: bold;">About Thalia</p>
            <ul>
                <a href="#">Stay connected with Thalia</a><br>
                <a href="#">All rights reserved</a><br>
                <a href="#">Terms of Use</a><br>
                <a href="#">Privacy Policy</a><br>
            </ul>
        </div>
        <div class="Service"> 
            <p style="font-weight: bold;">Service Center</p>
            <ul>
                <a href="#">Help</a><br>
                <a href="#">Contact</a><br>
                <a href="#">Returns</a><br>
                <a href="#">Public Administration Service</a><br>
            </ul>
        </div>
        <div class="Shopp"> 
            <p style="font-weight: bold;">All about shopping</p>
            <ul>
                <a href="#">Questions about the order</a><br>
                <a href="#">Buy and pay</a><br>
                <a href="#">Shipping and delivery</a><br>
                <a href="#">Data protection</a><br>
            </ul>
        </div>
    </div>

    <div class="SocialMedias">
        <img src="Payments.png" alt="Payments" id="Payment" ></img>
        
        <a href="https://www.facebook.com/thalia.de" target="_blank"> <img src="https://images.thalia.media/Footer/-/f3ab2209619a458ab9f049e58fb45cbb/facebook.png" alt="facebook" id="FB"> </a>
    
        <a href="https://www.instagram.com/thalia_buchhandlungen/" target="_blank"> <img src="https://images.thalia.media/Footer/-/323c0decad694b80bb019605c85d10d5/instagram.png" id="IG">  </a>
        
        <a href="https://www.tiktok.com/@thalia_buchhandlungen" target="_blank"> <img src="https://images.thalia.media/Footer/-/17b9a0625daf4e40aacffb34e371f803/TikTok.png" id="Tiktok"> </a>
    
    </div>
    <p id="ps">Copyright © 2023 Thalia DE. All rights reserved.</p>
    <br>
    </footer>

    <script>
        function redirectToSignUp() {
            window.open('LoginForm.html', '_blank');
        }
    
        function validimi() {
            let email = document.getElementById("email").value;
            let password = document.getElementById("password").value;
    
            let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert("Please enter a valid email!");
                return false;
            }
    
            if (password.length < 8) {
                alert("Password should be more than 8 characters long");
                return false;
            }
            
            alert("Login was successful");
            return true;
        }
    </script>
</body>


</html>